﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ses11DataSet
{
    class Program
    {
        static void Main(string[] args)
        {
            //Still need a connection string
            string conStr = @"Server=localhost\SQLEXPRESS;Integrated Security=true;Database=AutoLot";
            //Create a data adapter
            DbDataAdapter da = new SqlDataAdapter("select * from inventory", conStr);
            //Do some mapping
            DataTableMapping dtm = da.TableMappings.Add("Inventory", "Current Inventory");
            dtm.ColumnMappings.Add("CarId", "Car ID");
            dtm.ColumnMappings.Add("PetName", "Name of car");
            //Create a new data set (copy of your db in your app)
            DataSet ds = new DataSet("AutoLotDataSet");
            //Fill the dataset with the table from our DB using DA
            da.Fill(ds, "Inventory");
            PrintDataSet(ds);
            Console.ReadLine();
        }
        static void PrintDataSet(DataSet ds)
        {
            //Display the DataSet name
            Console.WriteLine($"DataSet name: {ds.DataSetName}");
            //For each table inside the dataset
            foreach (DataTable tbl in ds.Tables)
            {
                //Display table name
                Console.WriteLine($"Table: {tbl.TableName}");
                //Display all column names
                foreach (DataColumn item in tbl.Columns)
                {
                    Console.Write($"{item.ColumnName}\t\t|");
                }
                Console.WriteLine();
                //For each row
                foreach (DataRow row in tbl.Rows)
                {
                    foreach (DataColumn col in tbl.Columns)
                    {
                        Console.Write($"{row[col]}\t\t|");
                    }
                    Console.WriteLine();
                }
            }
        }
    }
   
}
