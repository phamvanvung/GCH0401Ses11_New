﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TypedDataSet.AutoLotDataSetTableAdapters;

namespace TypedDataSet
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create the data set.
            AutoLotDataSet autoLotDataSet = new AutoLotDataSet();
            //Populate the data.
            InventoryTableAdapter inventoryAdapter = new InventoryTableAdapter();
            inventoryAdapter.Fill(autoLotDataSet.Inventory);
            
            //try to insert.
            insertInventory(autoLotDataSet);
            insertInventory(autoLotDataSet);
            //autoLotDataSet.AcceptChanges();
            inventoryAdapter.Update(autoLotDataSet);
            PrintDataSet(autoLotDataSet);
            Console.Read();
        }
        static void insertInventory(AutoLotDataSet ald) {
            Console.WriteLine("Please insert Color: ");
            string color = Console.ReadLine();
            Console.WriteLine("Please insert Make: ");
            string make = Console.ReadLine();
            Console.WriteLine("Please insert PetName: ");
            string petName = Console.ReadLine();
            ald.Inventory.AddInventoryRow(make, color, petName);
            
        }
        static void PrintDataSet(DataSet ds)
        {
            //Display the DataSet name
            Console.WriteLine($"DataSet name: {ds.DataSetName}");
            //For each table inside the dataset
            foreach (DataTable tbl in ds.Tables)
            {
                //Display table name
                Console.WriteLine($"Table: {tbl.TableName}");
                //Display all column names
                foreach (DataColumn item in tbl.Columns)
                {
                    Console.Write($"{item.ColumnName}\t\t|");
                }
                Console.WriteLine();
                //For each row
                foreach (DataRow row in tbl.Rows)
                {
                    foreach (DataColumn col in tbl.Columns)
                    {
                        Console.Write($"{row[col]}\t\t|");
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}
