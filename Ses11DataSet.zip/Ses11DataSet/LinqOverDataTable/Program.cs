﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqOverDataTable
{
    class Program
    {
        static void Main(string[] args)
        {
            string conStr = @"Server=localhost\SQLEXPRESS;Integrated Security=true;Database=AutoLot";
            DbDataAdapter da = new SqlDataAdapter("select * from Inventory", conStr);
            DataSet ds = new DataSet("AutoLotDataSet");
            da.Fill(ds, "Inventory");
            //Now we access to the Inventory table
            DataTable tbl = ds.Tables["Inventory"];
            LinqOverDataTableTest(tbl);
            Console.WriteLine("Use field");
            LinqOverDataTableWithField(tbl);
            Console.WriteLine("Test linq result to DataTable");
            LinqResultToDataTable(tbl);
            Console.ReadLine();
        }

        private static void LinqOverDataTableTest(DataTable tbl)
        {
            //Use linq over it.
            var subset = from c in tbl.AsEnumerable()
                         where ((string)c["Color"]).Equals("Black")
                         select c;
            //Display all the cars
            foreach (var item in subset)
            {
                Console.WriteLine($"{item["CarId"]} is {item["Make"]}");
            }
        }
        private static void LinqOverDataTableWithField(DataTable tbl)
        {
            //Use linq over it.
            var subset = from c in tbl.AsEnumerable()
                         where c.Field<string>("Color").Equals("Black")
                         select new {
                             CarId = c.Field<int>("CarId"),
                             Color = c.Field<string>("Color"),
                             Make = c.Field<string>("Make")
            };//Don't have to select the whole row
            //Display all the cars
            foreach (var item in subset)
            {
                Console.WriteLine($"Car {item.CarId} is a {item.Color} {item.Make}");
            }
        }
        private static void LinqResultToDataTable(DataTable tbl)
        {
            //Use linq over it.
            var subset = from c in tbl.AsEnumerable()
                         where c.Field<string>("Color").Equals("Black")
                         select c;
            //Convert results of Linq to DataTable
            DataTable blackCars = subset.CopyToDataTable();
            //Display all the cars
            foreach (DataRow row in blackCars.Rows)
            {
                foreach (DataColumn col in blackCars.Columns)
                {
                    Console.Write($"{row[col]}\t");
                }
                Console.WriteLine();
            }
        }
    }
}
